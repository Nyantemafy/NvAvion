package com.itu.vol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolApplicationTests {

	@Test
	void contextLoads() {
	}

}
