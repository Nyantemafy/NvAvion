package com.itu.vol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolApplication.class, args);
	}

}
